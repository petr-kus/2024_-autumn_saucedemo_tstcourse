def test_addition():
    assert 1 + 1 == 2